package com.csc460.fitnessapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FitnessappApplicationTests {

	@Test
	void contextLoads() {
	}

}
