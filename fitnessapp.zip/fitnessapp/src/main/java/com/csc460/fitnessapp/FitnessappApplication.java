package com.csc460.fitnessapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FitnessappApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitnessappApplication.class, args);
	}

}
